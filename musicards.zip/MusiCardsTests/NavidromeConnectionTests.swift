import Foundation
import XCTest
@testable import MusiCards

final class NavidromeConnectionTests: XCTestCase {
    private let endpointIdentity = NavidromeServerIdentity(
        serverVersion: "0.58.0", protocolVersion: "1.16.1"
    )

    @MainActor
    private func savedStore(
        home: String = "", remote: String = "",
        identifier: NavidromeIdentifierStub,
        reachability: (any NavidromeIdentifying)? = nil
    ) async throws -> NavidromeConnectionStore {
        let suite = "NavidromeEndpointTests.\(UUID().uuidString)"
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        addTeardownBlock { UserDefaults(suiteName: suite)?.removePersistentDomain(forName: suite) }
        let store = NavidromeConnectionStore(
            defaults: defaults, credentialStore: NavidromeCredentialStoreStub(),
            client: identifier, reachabilityClient: reachability ?? identifier
        )
        store.homeServerURL = home
        store.remoteServerURL = remote
        store.username = "listener"
        store.password = "password"
        await store.verifyAndSave()
        XCTAssertNil(store.errorMessage)
        return store
    }

    @MainActor
    func testOnlyLocalConnectionBecomesUnavailableInsteadOfUsingStaleEndpoint() async throws {
        let identifier = NavidromeIdentifierStub(resultsByHost: ["server.local": .success(endpointIdentity)])
        let store = try await savedStore(home: "http://server.local:4533", identifier: identifier)
        XCTAssertEqual(store.endpointState, .local)
        XCTAssertTrue(store.canUseRenderer)
        XCTAssertEqual(try store.rendererCredentials().profile.baseURL.host, "server.local")

        await identifier.setResult(.failure(NavidromeConnectionError.invalidResponse), for: "server.local")
        await store.networkDidChange()
        XCTAssertEqual(store.endpointState, .unavailable)
        XCTAssertNil(store.activeEndpointURL)
        XCTAssertFalse(store.canUseRenderer)
        XCTAssertThrowsError(try store.rendererCredentials())
        do {
            try await store.requirePlaybackConnection()
            XCTFail("An unreachable saved address must not authorize playback")
        } catch {
            XCTAssertEqual(error as? NavidromeConnectionStoreError, .serverUnavailable)
        }
    }

    @MainActor
    func testOnlyRemoteConnectionNeverProvidesRendererCredentials() async throws {
        let identifier = NavidromeIdentifierStub(resultsByHost: ["music.example.com": .success(endpointIdentity)])
        let store = try await savedStore(remote: "https://music.example.com", identifier: identifier)
        XCTAssertEqual(store.endpointState, .remote)
        XCTAssertEqual(store.activeEndpointURL?.host, "music.example.com")
        try await store.requirePlaybackConnection()
        XCTAssertFalse(store.canUseRenderer)
        XCTAssertThrowsError(try store.rendererCredentials()) { error in
            XCTAssertEqual(error as? NavidromeConnectionStoreError, .localConnectionRequired)
        }
    }

    @MainActor
    func testPlaybackReusesVerifiedRouteWithoutProbingBetweenTracks() async throws {
        let identifier = NavidromeIdentifierStub(resultsByHost: ["music.example.com": .success(endpointIdentity)])
        let store = try await savedStore(remote: "https://music.example.com", identifier: identifier)
        let initialCalls = await identifier.requestedHosts.count
        try await store.requirePlaybackConnection()
        try await store.requirePlaybackConnection()
        let playbackCalls = await identifier.requestedHosts.count
        XCTAssertEqual(playbackCalls, initialCalls)
        await store.refreshReachableEndpoint()
        let foregroundCalls = await identifier.requestedHosts.count
        XCTAssertEqual(foregroundCalls, initialCalls + 1)
    }

    @MainActor
    func testRestoredLocalHTTPSAddressStaysLocalAndRequiresFreshVerification() async throws {
        let suite = "NavidromeRestoreTests.\(UUID().uuidString)"
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
        defer { defaults.removePersistentDomain(forName: suite) }
        let credentials = NavidromeCredentialStoreStub()
        let identifier = NavidromeIdentifierStub(resultsByHost: ["server.local": .success(endpointIdentity)])
        let original = NavidromeConnectionStore(
            defaults: defaults, credentialStore: credentials,
            client: identifier, reachabilityClient: identifier
        )
        original.homeServerURL = "https://server.local:4533"
        original.username = "listener"
        original.password = "password"
        await original.verifyAndSave()

        let restored = NavidromeConnectionStore(
            defaults: defaults, credentialStore: credentials,
            client: identifier, reachabilityClient: identifier
        )
        XCTAssertEqual(restored.homeBaseURL?.absoluteString, "https://server.local:4533")
        XCTAssertNil(restored.remoteBaseURL, "A local HTTPS URL must not become a remote address on restart")
        XCTAssertEqual(restored.endpointState, .checking)
        XCTAssertFalse(restored.canUseRenderer)
        XCTAssertThrowsError(try restored.rendererCredentials())
        await restored.refreshReachableEndpoint()
        XCTAssertEqual(restored.endpointState, .local)
        XCTAssertTrue(restored.canUseRenderer)
    }

    @MainActor
    func testBothAddressesPreferLocalFallBackToRemoteAndReturnToLocal() async throws {
        let identifier = NavidromeIdentifierStub(resultsByHost: [
            "server.local": .success(endpointIdentity), "music.example.com": .success(endpointIdentity)
        ])
        let store = try await savedStore(
            home: "http://server.local:4533", remote: "https://music.example.com", identifier: identifier
        )
        XCTAssertEqual(store.endpointState, .local)
        await identifier.setResult(.failure(NavidromeConnectionError.invalidResponse), for: "server.local")
        await store.networkDidChange()
        XCTAssertEqual(store.endpointState, .remote)
        XCTAssertEqual(try store.catalogCredentials().profile.baseURL.host, "music.example.com")
        XCTAssertThrowsError(try store.rendererCredentials())

        await identifier.setResult(.success(endpointIdentity), for: "server.local")
        await store.networkDidChange()
        XCTAssertEqual(store.endpointState, .local)
        XCTAssertEqual(try store.rendererCredentials().profile.baseURL.host, "server.local")
    }

    @MainActor
    func testLateReachabilityResponseCannotRestoreRemovedServer() async throws {
        let identifier = NavidromeIdentifierStub(resultsByHost: ["server.local": .success(endpointIdentity)])
        let paused = PausedNavidromeIdentifier()
        let store = try await savedStore(
            home: "http://server.local:4533", identifier: identifier, reachability: paused
        )
        let task = Task { await store.networkDidChange() }
        await paused.waitForRequest()
        XCTAssertEqual(store.endpointState, .checking)
        store.removeServer()
        await paused.complete(with: endpointIdentity)
        await task.value
        XCTAssertNil(store.savedProfile)
        XCTAssertEqual(store.endpointState, .notConfigured)
        XCTAssertFalse(store.canUseRenderer)
    }

    func testPublicAndMalformedHostsNeverPassLocalHTTPPolicy() throws {
        for host in ["10.0.0.1.example.net", "192.168.1.5.evil.net", "[2001:db8::1]", "192.168.999.1", "2130706433", "0x08080808", "010.0.0.1", "[::ffff:8.8.8.8]"] {
            let url = URL(string: "http://\(host):4533")!
            XCTAssertThrowsError(try NavidromeRendererServerURL.validated(url.absoluteString), host)
            let profile = NavidromeServerProfile(name: "Test", baseURL: url, username: "listener")
            let builder = OpenSubsonicRequestBuilder()
            XCTAssertThrowsError(try builder.rendererStreamURL(profile: profile, password: "test", salt: "abcdef", songID: "1"), host)
            XCTAssertThrowsError(try builder.pingRequest(profile: profile, password: "test", salt: "abcdef", allowsInsecureLocalHTTP: true), host)
        }
        for host in ["192.168.1.5", "10.0.0.1", "server.local", "umbrel", "[::1]", "[fd00::1]", "[fe80::1]"] {
            XCTAssertNoThrow(try NavidromeRendererServerURL.validated("http://\(host):4533"), host)
        }
    }
    @MainActor
    func testCancelledVerificationCannotSaveLateResponse() async throws {
        let suiteName = "NavidromeConnectionCancellationTests.\(UUID().uuidString)"
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suiteName))
        defer { defaults.removePersistentDomain(forName: suiteName) }
        let identifier = PausedNavidromeIdentifier()
        let store = NavidromeConnectionStore(
            defaults: defaults,
            credentialStore: NavidromeCredentialStoreStub(),
            client: identifier,
            reachabilityClient: identifier
        )
        store.remoteServerURL = "https://music.example.com"
        store.username = "listener"
        store.password = "password"

        let task = try XCTUnwrap(store.beginVerification())
        await identifier.waitForRequest()
        XCTAssertTrue(store.isConnecting)

        store.cancelPendingVerification()
        XCTAssertFalse(store.isConnecting)

        await identifier.complete(with: NavidromeServerIdentity(
            serverVersion: "0.58.0",
            protocolVersion: "1.16.1"
        ))
        await task.value

        XCTAssertNil(store.savedProfile)
        XCTAssertNil(store.identity)
        XCTAssertNil(store.errorMessage)
    }

    @MainActor
    func testConnectionCanBeSavedWhenOnlyRemoteAddressIsReachable() async throws {
        let suiteName = "NavidromeConnectionTests.\(UUID().uuidString)"
        let defaults = try XCTUnwrap(UserDefaults(suiteName: suiteName))
        defer { defaults.removePersistentDomain(forName: suiteName) }
        let identity = NavidromeServerIdentity(
            serverVersion: "0.58.0",
            protocolVersion: "1.16.1"
        )
        let identifier = NavidromeIdentifierStub(
            resultsByHost: [
                "umbrel.local": .failure(NavidromeConnectionError.invalidResponse),
                "music.example.com": .success(identity)
            ]
        )
        let credentials = NavidromeCredentialStoreStub()
        let store = NavidromeConnectionStore(
            defaults: defaults,
            credentialStore: credentials,
            client: identifier,
            reachabilityClient: identifier
        )
        store.homeServerURL = "http://umbrel.local:4533"
        store.remoteServerURL = "https://music.example.com"
        store.username = "listener"
        store.password = "password"

        await store.verifyAndSave()

        XCTAssertNil(store.errorMessage)
        XCTAssertEqual(store.savedProfile?.baseURL.host, "music.example.com")
        XCTAssertEqual(store.homeBaseURL?.host, "umbrel.local")
        XCTAssertEqual(store.remoteBaseURL?.host, "music.example.com")
        XCTAssertEqual(store.identity, identity)
        XCTAssertTrue(store.statusMessage?.contains("other address") == true)
    }

    private func pingRequest(
        baseURL: URL,
        username: String = "listener",
        password: String = "password",
        salt: String = "abcdef"
    ) throws -> URLRequest {
        let profile = NavidromeServerProfile(
            name: "Test Server",
            baseURL: baseURL,
            username: username
        )

        return try OpenSubsonicRequestBuilder().pingRequest(
            profile: profile,
            password: password,
            salt: salt
        )
    }

    private func verify(_ data: Data) throws -> NavidromeServerIdentity {
        let envelope = try JSONDecoder().decode(OpenSubsonicPingEnvelope.self, from: data)
        return try NavidromeServerVerifier.identity(from: envelope.response)
    }

    func testSaltedTokenMatchesKnownVector() throws {
        let token = OpenSubsonicAuthentication.token(
            password: "sesame",
            salt: "c19b2d"
        )

        XCTAssertEqual(token, "26719a1196d2a940705a59634eb18eab")
    }

    func testPingRequestUsesHTTPSPostAndDoesNotExposePassword() throws {
        let request = try pingRequest(
            baseURL: URL(string: "https://music.example.com")!,
            password: "super secret",
            salt: "abcdef"
        )

        XCTAssertEqual(request.httpMethod, "POST")
        XCTAssertEqual(request.url?.absoluteString, "https://music.example.com/rest/ping")
        XCTAssertNil(request.url?.query)

        let body = try XCTUnwrap(request.httpBody.flatMap { String(data: $0, encoding: .utf8) })
        XCTAssertTrue(body.contains("u=listener"))
        XCTAssertTrue(body.contains("s=abcdef"))
        XCTAssertTrue(body.contains("t="))
        XCTAssertTrue(body.contains("v=1.16.1"))
        XCTAssertTrue(body.contains("c=MusiCards"))
        XCTAssertTrue(body.contains("f=json"))
        XCTAssertFalse(body.contains("super"))
        XCTAssertFalse(body.contains("secret"))
        XCTAssertFalse(body.contains("p="))
    }

    func testPingRequestPreservesServerPathPrefix() throws {
        let request = try pingRequest(
            baseURL: URL(string: "https://music.example.com/navidrome")!
        )

        XCTAssertEqual(request.url?.path, "/navidrome/rest/ping")
    }

    func testPingRequestDoesNotDuplicateRestPath() throws {
        let request = try pingRequest(
            baseURL: URL(string: "https://music.example.com/navidrome/rest/")!
        )

        XCTAssertEqual(request.url?.path, "/navidrome/rest/ping")
    }

    func testValidatedProfileAcceptsHTTPSWithPort() throws {
        let profile = try NavidromeServerProfile.validated(
            name: "Home",
            serverURL: "https://music.example.com:4533",
            username: "listener"
        )

        XCTAssertEqual(profile.baseURL.absoluteString, "https://music.example.com:4533")
    }

    func testValidatedProfileAcceptsCaseInsensitiveHTTPS() throws {
        XCTAssertNoThrow(
            try NavidromeServerProfile.validated(
                name: "Home",
                serverURL: "HTTPS://music.example.com",
                username: "listener"
            )
        )
    }

    func testValidatedProfileAddsHTTPSToMissingScheme() throws {
        let profile = try NavidromeServerProfile.validated(
            name: "Home",
            serverURL: "music.example.com",
            username: "listener"
        )

        XCTAssertEqual(profile.baseURL.absoluteString, "https://music.example.com")
    }

    func testValidatedProfileRejectsNonHTTPSSchemes() {
        XCTAssertThrowsError(
            try NavidromeServerProfile.validated(
                name: "Home",
                serverURL: "http://music.example.com",
                username: "listener"
            )
        ) { error in
            XCTAssertEqual(
                error as? NavidromeProfileValidationError,
                .secureConnectionRequired
            )
        }

        for serverURL in ["ftp://music.example.com", "file:///tmp/music"] {
            XCTAssertThrowsError(
                try NavidromeServerProfile.validated(
                    name: "Home",
                    serverURL: serverURL,
                    username: "listener"
                ),
                "Expected rejection for \(serverURL)"
            ) { error in
                XCTAssertTrue(error is NavidromeProfileValidationError)
            }
        }
    }

    func testAlbumListRequestUsesAlphabeticalPagination() throws {
        let profile = NavidromeServerProfile(
            name: "Test Server",
            baseURL: URL(string: "https://music.example.com/navidrome")!,
            username: "listener"
        )
        let request = try OpenSubsonicRequestBuilder().albumListRequest(
            profile: profile,
            password: "password",
            salt: "abcdef",
            offset: 500,
            size: 500
        )

        XCTAssertEqual(
            request.url?.path,
            "/navidrome/rest/getAlbumList2"
        )
        let body = try XCTUnwrap(
            request.httpBody.flatMap { String(data: $0, encoding: .utf8) }
        )
        XCTAssertTrue(body.contains("type=alphabeticalByName"))
        XCTAssertTrue(body.contains("offset=500"))
        XCTAssertTrue(body.contains("size=500"))
    }

    func testAlbumDetailRequestUsesServerAlbumID() throws {
        let profile = NavidromeServerProfile(
            name: "Test Server",
            baseURL: URL(string: "https://music.example.com")!,
            username: "listener"
        )
        let request = try OpenSubsonicRequestBuilder().albumRequest(
            profile: profile,
            password: "password",
            salt: "abcdef",
            albumID: "album/id"
        )

        XCTAssertEqual(request.url?.path, "/rest/getAlbum")
        let body = try XCTUnwrap(
            request.httpBody.flatMap { String(data: $0, encoding: .utf8) }
        )
        XCTAssertTrue(body.contains("id=album%2Fid"))
    }

    func testRawStreamRequestUsesSongIDWithoutTranscodingParameters() throws {
        let profile = NavidromeServerProfile(
            name: "Test Server",
            baseURL: URL(string: "https://music.example.com/navidrome")!,
            username: "listener"
        )
        let request = try OpenSubsonicRequestBuilder().streamRequest(
            profile: profile,
            password: "super secret",
            salt: "abcdef",
            songID: "song/id"
        )

        XCTAssertEqual(request.httpMethod, "POST")
        XCTAssertEqual(request.url?.path, "/navidrome/rest/stream")
        XCTAssertNil(request.url?.query)
        XCTAssertEqual(
            request.value(forHTTPHeaderField: "Accept"),
            "audio/*, application/octet-stream"
        )

        let body = try XCTUnwrap(
            request.httpBody.flatMap { String(data: $0, encoding: .utf8) }
        )
        XCTAssertTrue(body.contains("id=song%2Fid"))
        XCTAssertTrue(body.contains("format=raw"))
        XCTAssertFalse(body.localizedCaseInsensitiveContains("bitrate"))
        XCTAssertFalse(body.localizedCaseInsensitiveContains("transcod"))
        XCTAssertFalse(body.contains("super"))
        XCTAssertFalse(body.contains("secret"))
        XCTAssertFalse(body.contains("p="))
    }

    func testRendererStreamURLCarriesTokenButNeverPlainPassword() throws {
        let profile = NavidromeServerProfile(
            name: "Test Server",
            baseURL: URL(string: "https://music.example.com/navidrome")!,
            username: "listener"
        )
        let url = try OpenSubsonicRequestBuilder().rendererStreamURL(
            profile: profile,
            password: "super secret",
            salt: "abcdef",
            songID: "song/id"
        )
        let components = try XCTUnwrap(
            URLComponents(url: url, resolvingAgainstBaseURL: false)
        )
        let query = Dictionary(
            uniqueKeysWithValues: (components.queryItems ?? []).map {
                ($0.name, $0.value ?? "")
            }
        )

        XCTAssertEqual(components.path, "/navidrome/rest/stream.view")
        XCTAssertEqual(query["f"], "json")
        XCTAssertEqual(query["u"], "listener")
        XCTAssertEqual(query["s"], "abcdef")
        XCTAssertEqual(query["id"], "song/id")
        XCTAssertEqual(query["format"], "raw")
        XCTAssertEqual(query["maxBitRate"], "0")
        XCTAssertEqual(
            query["t"],
            OpenSubsonicAuthentication.token(
                password: "super secret",
                salt: "abcdef"
            )
        )
        XCTAssertFalse(url.absoluteString.contains("super"))
        XCTAssertFalse(url.absoluteString.contains("secret"))
        XCTAssertNil(query["p"])
    }

    func testRendererAddressAllowsLocalHTTPButRejectsPublicHTTP() throws {
        XCTAssertEqual(
            try NavidromeRendererServerURL.validated("umbrel.local:4533")
                .absoluteString,
            "http://umbrel.local:4533"
        )
        XCTAssertEqual(
            try NavidromeRendererServerURL.validated("http://192.168.0.10:4533")
                .host,
            "192.168.0.10"
        )
        XCTAssertThrowsError(
            try NavidromeRendererServerURL.validated(
                "http://music.example.com:4533"
            )
        ) { error in
            XCTAssertEqual(
                error as? NavidromeRendererServerURLError,
                .insecurePublicAddress
            )
        }
    }

    func testRequestsAllowPrivateLocalHTTP() throws {
        let profile = NavidromeServerProfile(
            name: "Home LAN",
            baseURL: URL(string: "http://umbrel.local:4533")!,
            username: "listener"
        )
        let builder = OpenSubsonicRequestBuilder()

        XCTAssertNoThrow(
            try builder.pingRequest(
                profile: profile,
                password: "password",
                salt: "abcdef",
                allowsInsecureLocalHTTP: true
            )
        )
        XCTAssertNoThrow(
            try builder.pingRequest(
                profile: profile,
                password: "password",
                salt: "abcdef"
            )
        )
        XCTAssertEqual(
            try builder.rendererStreamURL(
                profile: profile,
                password: "password",
                salt: "abcdef",
                songID: "song-1"
            ).scheme,
            "http"
        )
    }

    func testAlbumResponsesDecodeReleaseMusicBrainzID() throws {
        let data = Data(
            """
            {
              "subsonic-response": {
                "status": "ok",
                "albumList2": {
                  "album": [{
                    "id": "album-1",
                    "name": "Release",
                    "artist": "Artist 1 feat. Artist 2",
                    "artists": [{
                      "id": "artist-1",
                      "name": "Artist 1"
                    }, {
                      "id": "artist-2",
                      "name": "Artist 2"
                    }],
                    "musicBrainzId": "189002e7-3285-4e2e-92a3-7f6c30d407a2"
                  }]
                }
              }
            }
            """.utf8
        )

        let envelope = try JSONDecoder().decode(
            OpenSubsonicAlbumListEnvelope.self,
            from: data
        )

        XCTAssertEqual(
            envelope.response.albumList?.albums.first?.musicBrainzID,
            "189002e7-3285-4e2e-92a3-7f6c30d407a2"
        )
        XCTAssertEqual(
            envelope.response.albumList?.albums.first?.artist,
            "Artist 1 feat. Artist 2"
        )
        XCTAssertEqual(
            envelope.response.albumList?.albums.first?.artists.map(\.name),
            ["Artist 1", "Artist 2"]
        )
    }

    func testAlbumDetailDecodesSongRecordingMusicBrainzIDs() throws {
        let data = Data(
            """
            {
              "subsonic-response": {
                "status": "ok",
                "album": {
                  "id": "album-1",
                  "name": "Release",
                  "musicBrainzId": "189002e7-3285-4e2e-92a3-7f6c30d407a2",
                  "song": [{
                    "id": "song-1",
                    "musicBrainzId": "bf99cae5-3b83-437a-a266-7126bd5653bf",
                    "discNumber": 2,
                    "track": 3,
                    "title": "Hi-Res Track",
                    "suffix": "flac",
                    "contentType": "audio/flac",
                    "size": 123456789,
                    "duration": 321,
                    "bitRate": 4512,
                    "samplingRate": 96000,
                    "bitDepth": 24,
                    "channelCount": 2
                  }]
                }
              }
            }
            """.utf8
        )

        let envelope = try JSONDecoder().decode(
            OpenSubsonicAlbumEnvelope.self,
            from: data
        )

        XCTAssertEqual(
            envelope.response.album?.songs.first?.musicBrainzID,
            "bf99cae5-3b83-437a-a266-7126bd5653bf"
        )
        let song = try XCTUnwrap(envelope.response.album?.songs.first)
        XCTAssertEqual(song.discNumber, 2)
        XCTAssertEqual(song.track, 3)
        XCTAssertEqual(song.title, "Hi-Res Track")
        XCTAssertEqual(song.suffix, "flac")
        XCTAssertEqual(song.contentType, "audio/flac")
        XCTAssertEqual(song.size, 123_456_789)
        XCTAssertEqual(song.duration, 321)
        XCTAssertEqual(song.bitRate, 4_512)
        XCTAssertEqual(song.samplingRate, 96_000)
        XCTAssertEqual(song.bitDepth, 24)
        XCTAssertEqual(song.channelCount, 2)
    }

    func testAuthenticatedRequestsRejectHTTP() {
        XCTAssertThrowsError(
            try pingRequest(baseURL: URL(string: "http://music.example.com")!)
        ) { error in
            XCTAssertEqual(error as? NavidromeConnectionError, .secureConnectionRequired)
        }
    }

    func testRequestBuilderRejectsNonHTTPSSchemes() {
        for serverURL in [
            "ftp://music.example.com",
            "file:///tmp/music"
        ] {
            XCTAssertThrowsError(
                try pingRequest(baseURL: URL(string: serverURL)!),
                "Expected rejection for \(serverURL)"
            ) { error in
                XCTAssertEqual(error as? NavidromeConnectionError, .secureConnectionRequired)
            }
        }
    }

    func testVerifierAcceptsModernNavidromeResponse() throws {
        let data = Data(
            """
            {
              "subsonic-response": {
                "status": "ok",
                "version": "1.16.1",
                "type": "navidrome",
                "serverVersion": "0.58.0",
                "openSubsonic": true
              }
            }
            """.utf8
        )

        let identity = try verify(data)

        XCTAssertEqual(identity.serverVersion, "0.58.0")
        XCTAssertEqual(identity.protocolVersion, "1.16.1")
    }

    func testVerifierRequiresOpenSubsonic() {
        let data = Data(
            """
            {
              "subsonic-response": {
                "status": "ok",
                "version": "1.16.1",
                "type": "navidrome"
              }
            }
            """.utf8
        )

        XCTAssertThrowsError(try verify(data)) { error in
            XCTAssertEqual(error as? NavidromeConnectionError, .openSubsonicRequired)
        }
    }

    func testVerifierRejectsNonNavidromeServer() {
        let data = Data(
            """
            {
              "subsonic-response": {
                "status": "ok",
                "version": "1.16.1",
                "type": "another-server",
                "openSubsonic": true
              }
            }
            """.utf8
        )

        XCTAssertThrowsError(try verify(data)) { error in
            XCTAssertEqual(
                error as? NavidromeConnectionError,
                .notNavidrome(serverType: "another-server")
            )
        }
    }

    func testVerifierSurfacesServerRejection() {
        let data = Data(
            """
            {
              "subsonic-response": {
                "status": "failed",
                "version": "1.16.1",
                "error": {
                  "code": 40,
                  "message": "Wrong username or password"
                }
              }
            }
            """.utf8
        )

        XCTAssertThrowsError(try verify(data)) { error in
            XCTAssertEqual(
                error as? NavidromeConnectionError,
                .serverRejected(code: 40, message: "Wrong username or password")
            )
        }
    }

    func testPersistedProfileContainsNoPassword() throws {
        let profile = NavidromeServerProfile(
            name: "Home",
            baseURL: URL(string: "https://music.example.com")!,
            username: "listener"
        )

        let data = try JSONEncoder().encode(profile)
        let json = try XCTUnwrap(String(data: data, encoding: .utf8))

        XCTAssertFalse(json.localizedCaseInsensitiveContains("password"))
    }
}

private actor PausedNavidromeIdentifier: NavidromeIdentifying {
    private var pendingRequest: CheckedContinuation<NavidromeServerIdentity, Error>?
    private var requestWaiters: [CheckedContinuation<Void, Never>] = []

    func identifyNavidrome(
        profile: NavidromeServerProfile,
        password: String,
        allowsInsecureLocalHTTP: Bool
    ) async throws -> NavidromeServerIdentity {
        try await withCheckedThrowingContinuation { continuation in
            pendingRequest = continuation
            requestWaiters.forEach { $0.resume() }
            requestWaiters.removeAll()
        }
    }

    func waitForRequest() async {
        guard pendingRequest == nil else { return }
        await withCheckedContinuation { continuation in
            requestWaiters.append(continuation)
        }
    }

    func complete(with identity: NavidromeServerIdentity) {
        pendingRequest?.resume(returning: identity)
        pendingRequest = nil
    }
}

private actor NavidromeIdentifierStub: NavidromeIdentifying {
    var resultsByHost: [String: Result<NavidromeServerIdentity, Error>]
    private(set) var requestedHosts: [String] = []

    func setResult(_ result: Result<NavidromeServerIdentity, Error>, for host: String) {
        resultsByHost[host] = result
    }

    init(resultsByHost: [String: Result<NavidromeServerIdentity, Error>]) {
        self.resultsByHost = resultsByHost
    }

    func identifyNavidrome(
        profile: NavidromeServerProfile,
        password: String,
        allowsInsecureLocalHTTP: Bool
    ) async throws -> NavidromeServerIdentity {
        requestedHosts.append(profile.baseURL.host ?? "")
        guard let result = resultsByHost[profile.baseURL.host ?? ""] else {
            throw NavidromeConnectionError.invalidResponse
        }
        return try result.get()
    }
}

private final class NavidromeCredentialStoreStub:
    NavidromeCredentialStoring, @unchecked Sendable {
    private let lock = NSLock()
    private var passwords: [UUID: String] = [:]

    func save(password: String, for profileID: UUID) throws {
        lock.withLock { passwords[profileID] = password }
    }

    func password(for profileID: UUID) throws -> String? {
        lock.withLock { passwords[profileID] }
    }

    func deletePassword(for profileID: UUID) throws {
        lock.withLock { _ = passwords.removeValue(forKey: profileID) }
    }
}
