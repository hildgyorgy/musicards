# MusiCards — Codex handoff

Living handoff for continuing on another Mac. Git and the user's latest
instructions take precedence. Never commit passwords, tokens, authenticated
media URLs, private server addresses or signing material here.

## Current checkpoint — 2026-11-06

- Branch: main; last committed checkpoint: cba4d7c (ui). It includes the original
  VU/UI update; 673e02a (refine) includes the earlier five review fixes.
- At session start main matched the local origin/main reference. No fetch was
  performed; this does not assert the live remote state.
- Main project: **2.2, build 11**. The user submitted 2.1; current App Store
  availability has not been rechecked. Project version does not prove publication.
- The iPad landscape override was removed intentionally and is committed.
  **Portrait-only iPad is intentional; preserve this change.**
- Shared scheme Run uses Release without LLDB intentionally. The user did not
  reproduce crackles outside Xcode. Audio System Trace showed deadline misses
  with debugger involvement; the exact mechanism was not proven. Temporary
  traces/exports were deleted at the user's request.

Start with `git status --short --branch` and `git log -5 --oneline`.

### Player UI update — 2026-11-06

Expanded source/output metadata now uses one line per source/output, without
SOURCE/OUTPUT headings. The expanded player's reserved row below the seek bar
shows two fine dotted RMS signal meters for native system playback only.
The C callback measures the rendered PCM without modifying it and publishes a
single atomic stereo-energy snapshot. The main actor reads it using existing
10 Hz progress updates; the view adds short interpolation, with no new timer.
Mono is mirrored. The scale is logarithmic (-50 to 0 dBFS), before OS/DAC volume.
UPnP has no local PCM and never displays a fabricated meter. Pause/failure/queue
changes clear the level; route changes clear old system data. Reduce Motion hides
the decorative animation. Collapsed players retain their output-name row.
Tests check stereo RMS, mono/underrun silence, unchanged output samples, the
display scale and pause/renderer/queue transitions. This update is in cba4d7c.
The full `Tools/verify.sh` run passed on 2026-11-06: main macOS tests, generic
iOS device build and all 62 Sync tests.

### Playback safety and testability update — 2026-11-06 (uncommitted)

- FLAC bridge initialization requires all callbacks and a live context, rejects
  repeat initialization before changing callback/context pointers, and leaves
  rejected wrappers reusable. Tests cover every missing argument and repeat init.
- The common playback coordinator explicitly tracks user intent and session
  lifetime. It skips superseded queued seeks, waits for seeks arriving during
  Play preparation, preserves Play when a newer user seek supersedes an implicit
  replay rewind, and prevents duplicate starts. Reset detaches old-session I/O
  logically: retained old decoders can finish but cannot delay or control new
  output. Pause is immediate; a later Play waits for same-session mutations.
- AudioUnitOutputDriving is an internal start/stop/dispose seam. The default
  driver calls the same Apple APIs; headless tests use the real core, DecodedPCM,
  feeder and C renderer with an inert output driver and controllably blocked
  decoder. They cover Pause, Play, replacement, start failure, non-finite seek,
  stop-before-dispose and release after in-flight cancellation.
- DecodedPCM still cancels before draining the feeder queue. In-flight work
  retains the session until it exits; tests verify Stop can return while old
  seek I/O stays blocked and that the session is freed once that seek returns.
  Do not remove the drain or free the renderer eagerly. Queue identity is now
  per decoder, so another decoder's feeder is not mistaken for this one.
- VU measurement is opt-in at the C boundary, disabled by default. Visible,
  active expanded-player views hold independent UUID leases; backgrounding,
  closing the player or Reduce Motion releases the view's lease. Routing enables
  it only for system playback and preserves that preference for new decoders.
  No signal scan or meter events occur without a request. PCM remains unchanged.
- A local optimized C microbenchmark (five median runs, 512 stereo frames,
  write plus render) measured about 0.124 microseconds/block disabled and 1.124
  enabled. This is a Mac microbenchmark, not an iPhone deadline certification.
  Full-sample double precision was retained; visibility gating saves the work
  entirely when unused. No extra timer was added.
- SearchViewModel accepts an injected coverArtLoader, defaulting to the existing
  shared cache. Library-first search tests now inject no network artwork loader.
  This removes real Cover Art Archive traffic from the barcode pagination test,
  which had exceeded its one-second polling allowance in a full run.

Verification: complete Tools/verify.sh passed (main macOS suite, generic iOS
device build, 62 Sync tests). All 23 targeted core/renderer/FLAC tests passed
with Address Sanitizer, including the final per-session feeder identity.
All 36 focused core/renderer/controller tests also passed with Thread Sanitizer;
no data races were reported in that run. A subsequent complete verify.sh run
passed with the additional actual-core replay-versus-explicit-seek regression.
Manual follow-up remains: real iPhone/Mac pause/seek/replay/route changes and
VU visibility/background transitions; no physical AVM was used in this session.

## Current product

- MusicBrainz Search, Release, Tracks, Artist & Discography and Player use the
  iOS/iPadOS card deck and macOS accordion. SOURCE, OUTPUT and help use native
  sheets. Share code except for actual platform differences.
- Home is the deliberate source/output setup; players display the active output.
  macOS has a small library-index creation link on Home.
- This device selects a folder containing library.json, generated by MusiCards
  for Mac or Sync from Picard-tagged files. This is intentional. Display readable
  provider/volume paths; original URLs and security-scoped bookmarks govern access.
  Folder restore avoids blocking startup. Source switching cancels pending
  connection work; sheet dismissal alone does not.
- Navidrome supplies catalog and MBIDs without library.json. SOURCE holds one
  account with optional local-network and remote HTTPS addresses, at least one
  required. Prefer reachable local, otherwise remote; renderers receive local
  when present. One unverified endpoint can be retained if the other verifies.
- System audio follows OS-selected speakers, USB DAC, Bluetooth or AirPlay.
  Route display is reactive. Names use normal case consistently; expanded
  source/output metadata use one line each. Never fabricate output bit depth.
- UPnP playback is functional for **Navidrome tracks only**, with direct
  server-to-renderer audio, AVTransport/DIDL-Lite, polling, optional volume/mute,
  SetNext staging and existing-renderer-session adoption.
- Discovery: multicast SSDP, bounded local /24 deep search, stored and manual
  address. Passive advertisements are an invisible helper. Tap selects immediately.
- User tests confirmed AVM playback and Macast deep-search discovery, seek,
  volume, transitions, output switching and five tracks with iPhone locked.
  Home multicast discovery remained unreliable. Do not infer certification of
  all renderers or sample-level gapless from these observations.
- Search scope, consolidated resets and origin-preserving barcode/Shazam retries
  are implemented. Availability is strictly Release-MBID based, not fuzzy names.
- Wikipedia prefers English, otherwise an artist-appropriate available language;
  the link displays the actual language code.

## Review fixes committed in 673e02a — 2026-11-02

1. Local-HTTP validation parses complete IPv4 and explicit local IPv6 ranges.
   Public, malformed and numeric-disguised hosts are rejected. Stream URL building
   independently checks local-only HTTP; the legacy ping bypass cannot permit
   public HTTP. Remote HTTPS remains supported.
2. Shared AudioPlaybackOperationCoordinator preserves latest user intent:
   Pause cancels seek auto-resume; Stop/replacement invalidates late results.
3. Play waits for decoder mutations; seeks serialize and only the latest resumes.
   C reset takes an atomic render-access flag while changing cursors. The callback
   never waits: it emits silence if reset holds the flag. Feeder writes/reset
   stay on the serial feeder queue. Seek UI publication checks queue generation.
4. UPnP STOPPED/NO_MEDIA_PRESENT advances only with known end-of-track evidence,
   within at most two seconds. Early/unknown-duration stops pause without consuming
   the queue; ERROR_OCCURRED reports failure. Last position/duration cover devices
   that reset position on Stop. Stale polls are invalidated.
5. SSDP LOCATION must be local HTTP(S). URLBase and service endpoints stay on the
   discovered host; different ports are allowed. Discovery and SOAP refuse HTTP
   redirects, including ones that could forward a token-bearing SOAP body.

Cross-host descriptions and redirecting renderers are intentionally rejected.
Retest AVM/Macast compatibility. A selected renderer still receives a reusable
Navidrome token by protocol design. This does not authenticate devices or secure
an untrusted LAN; DNS identity is not cryptographic. Never log authenticated
stream URLs or SOAP bodies. Do not loosen endpoint policy without a concrete,
documented compatibility requirement.

Regression tests cover disguised/public hosts, renderer stream validation,
hostile device/service URLs, same-host different ports, real loopback redirects,
Pause/Play/Stop during suspended seek, superseded seeks, concurrent C reset/render
and early renderer Stop. Existing natural-end/SetNext tests must remain green.
These five fixes are committed; the later safety changes above remain uncommitted.

## Verification

Run `./Tools/verify.sh`: whitespace, main macOS tests, generic iOS device build
without signing, then Sync macOS tests. It does not run iOS tests or validate
Store provisioning. The complete script passed on 2026-11-02 after the review
fixes: 229 main-app macOS tests, the generic iOS device build and 62 Sync tests.
After the final numeric-host hardening, Navidrome/discovery tests and the iOS
build passed again. The seven final audio callback/transport-coordination tests
also passed, including the additional Pause-during-replay regression.

Xcode warns that the installed CoreSimulator service is older than its framework.
macOS tests and generic iOS device builds work; do not claim simulator validation.

Manual follow-up: seek → Pause, paused seek → Play, rapid seeks, output switching,
early renderer Stop and normal track transitions on physical Apple devices and
AVM/Macast. No physical renderer was used by the agent for the November fixes.
Keep audio quality checks separate from sanitizer/debugger timing.

## Architecture and next work

Read PLAYER_ARCHITECTURE.md for product decisions; current code and this handoff
supersede its historical placeholders. Relevant files under MusiCards/:

- App/MusiCardsAppModel.swift: composition and selection/load coordination.
- Playback/PlaybackController.swift: queue, commands and generations.
- Playback/AudioUnitPlaybackCore.swift: shared lifecycle and operation coordination.
- Playback/MacSystemPlaybackEngine.swift and IOSSystemPlaybackEngine.swift:
  platform device/session policy.
- Playback/MCPPCMRenderer.c: realtime consumer; no blocking, allocation, logging
  or Swift actor entry in the callback.
- Playback/LocalAudioFileDecoder.swift, RemoteAudioFileDecoder.swift,
  LibFLACRemoteAudioDecoder.swift, MCPFLACDecoderBridge.c: decoder/feeder path.
- RemoteLibrary/HTTPRandomAccessByteSource.swift: remote range reads.
- Playback/UPnP/: discovery, endpoint policy, SOAP and renderer transport.
- LibraryAccess/ and RemoteLibrary/: providers, Navidrome and credentials.
- ViewModels/SearchViewModel.swift: search and progressive merging.

See Documentation/MusiCards_Roadmap.md. Current priority is hardening/release
verification of existing UPnP playback. Local hog/exclusive mode and local gapless
remain deferred. Broader filtering and mini-player are optional decisions.
Do not start broad AppModel/SearchViewModel refactoring from line counts alone.
An independent decoder/C-bridge memory-safety audit remains worthwhile and was
not completed by this review.

Historical references:
- Documentation/Experiments/MusiCards_Navidrome_AVM_handoff.md
- Documentation/MusiCards_Roadmap_No_3_ UPnP_Renderer_Task.md
- Tools/UPnP/navidrome_avm_setnext_probe.command

## Sync and collaboration

Sync is a separate macOS Apple-silicon app (project 1.0/build 2). Preserve one-way
Check → Preview → Sync → Verify, real rsync progress, deletion previews and NFC/NFD.
Before editing read Documentation/MusiCards Sync/MusiCards-Sync_base_info.md,
NFD-NFC.md there, and ThirdParty/rsync/README.md and NOTICE.md. Preserve third-party
licensing/provenance and its dedicated UI.

Main app targets Apple-silicon macOS and iOS/iPadOS 26+. Multicast approval was
enabled by the user; macOS UDP discovery uses client/server sandbox capabilities.
Do not change signing/capabilities speculatively or rename Keychain services and
preference keys without migration.

MetaBrainz 2.0 announcement was published. Prepared Reddit/other promotional copy
was not confirmed published. Do not infer Store or announcement publication.

Preserve unrelated edits, explain consequential work and stay within approved
scope. Do not commit, push or publish implicitly. Update this file after material
sessions; commit/push intended changes before switching Macs and inspect Git on
the destination machine.
