//
//  MusiCardsAppModel.swift
//  MusiCards
//
//  Created by Hild György on 2026. 04. 07..
//

import Foundation
import SwiftUI
import Combine
import OSLog
import Network
#if canImport(UIKit)
import UIKit
#endif
#if canImport(AppKit)
import AppKit
#endif
#if os(iOS)
import MediaPlayer
#endif

@MainActor
final class MusiCardsAppModel: ObservableObject {
    nonisolated private static let shazamLogger = Logger(
        subsystem: "com.hildgyorgy.MusiCards",
        category: "Shazam"
    )
    nonisolated private static let rendererAdoptionLogger = Logger(
        subsystem: "com.hildgyorgy.MusiCards",
        category: "RendererAdoption"
    )

    @Published var deckSelection = DeckSelection<MusiCardID>(
        activeID: .home,
        activeSlotIndex: 0
    )
    @Published var selectedReleaseID: String?
    @Published var selectedRelease: MBRelease?
    @Published var selectedReleaseCover: PlatformImage?
    @Published var isLoadingRelease: Bool = false
    @Published var selectedArtistID: String?
    @Published var selectedArtist: MBArtistDetail?
    @Published var selectedArtistName: String = ""
    @Published var selectedArtistLifeSpan: String?
    @Published var isLoadingArtistHeader: Bool = false
    @Published var isLoadingArtistWikipedia: Bool = false
    @Published var isLoadingArtistDiscography: Bool = false
    @Published var artistReleaseGroups: [MBReleaseGroupSummary] = []
    @Published var discographyError: Error?
    @Published var artistWikipedia: WikipediaSummary?
    @Published var artistWikipediaError: Error?
    @Published var isArtistWikipediaUnavailable: Bool = false
    @Published var releaseError: Error?
    @Published var artistError: Error?
    @Published var recentArtists: [SearchArtistRow] = []
    @Published var recentReleases: [SearchReleaseRow] = []
    @Published var nowPlayingRelease: SearchReleaseRow?
    @Published private(set) var hasCurrentPlaybackItem = false

    @Published var isShazamListening: Bool = false
    @Published var shazamStatusMessage: String?

    // Pagination for release groups
    @Published var isLoadingMoreReleaseGroups: Bool = false
    @Published var hasMoreReleaseGroups: Bool = false

    @Published var activeLibrarySource: LibrarySource? {
        didSet {
            libraryManager.setActiveSource(activeLibrarySource)
            LibrarySourcePreference.save(activeLibrarySource)
            if activeLibrarySource != .navidrome,
               rendererBrowser.hasSelectedRendererPreference {
                rendererBrowser.selectSystemAudioImmediately()
            }
        }
    }

    let searchViewModel: SearchViewModel
    let trackDetailStore: TrackDetailStore
    let classicalMetadataStore: ClassicalMetadataStore
    let playbackController: PlaybackController
    let localLibrary: LocalLibraryStore
    let libraryManager: LibraryManager
    let navidromeConnection: NavidromeConnectionStore
    let rendererBrowser: UPnPRendererBrowser
    private let releasePlaybackQueueBuilder: ReleasePlaybackQueueBuilder

    private var localPlaybackNowPlayingCoordinator:
        PlatformNowPlayingCoordinator?
    private var playbackItemObservation: AnyCancellable?
    private var searchModeObservation: AnyCancellable?
    private var rendererOutputObservation: AnyCancellable?
    private var endpointObservation: AnyCancellable?
    private let networkMonitor = NWPathMonitor()

    private let musicBrainzService = MusicBrainzService()
    private let releaseDetailLoader: @Sendable (String) async throws -> MBRelease
    private let releaseCoverLoader: @Sendable (String) async -> PlatformImage?
    private let artistDetailLoader:
        @Sendable (String) async throws -> MBArtistDetail
    private let artistReleaseGroupsLoader:
        @Sendable (String, Int, Int) async throws
        -> (groups: [MBReleaseGroupSummary], hasMore: Bool)
    private let artistWikipediaLoader:
        @Sendable (URL) async throws -> WikipediaSummary?
    private let recentContentCache: RecentContentCache

    private let recentArtistsKey = "recentArtists"
    private let recentReleasesKey = "recentReleases"

#if os(iOS)
    private let shazamService = ShazamRecognitionService()
    private var nowPlayingReleaseGroupID: String?
    private var nowPlayingReleaseGroupTitle: String?
    private var nowPlayingArtistName: String?
    private var nowPlayingObserver: NSObjectProtocol?
    #endif

    private let releaseGroupsPageSize: Int = 25
    private var releaseGroupsOffset: Int = 0
    private var currentArtistIDForGroups: String?
    private var releaseSelectionGeneration: UInt64 = 0
    private var releaseLoadTask: Task<Void, Never>?
    private var isBackgroundReleaseLoad = false
    private var artistSelectionGeneration: UInt64 = 0
    private var artistLoadTask: Task<Void, Never>?
    private var artistWikipediaTask: Task<Void, Never>?
    private var artistDiscographyTask: Task<Void, Never>?
    private var artistPaginationTask: Task<Void, Never>?
    private var libraryArtistResolutionTask: Task<Void, Never>?

    init(
        playbackEngine: PlaybackEngine? = nil,
        releaseDetailLoader: (@Sendable (String) async throws -> MBRelease)? = nil,
        releaseCoverLoader: (@Sendable (String) async -> PlatformImage?)? = nil,
        artistDetailLoader:
            (@Sendable (String) async throws -> MBArtistDetail)? = nil,
        artistReleaseGroupsLoader:
            (@Sendable (String, Int, Int) async throws
            -> (groups: [MBReleaseGroupSummary], hasMore: Bool))? = nil,
        artistWikipediaLoader:
            (@Sendable (URL) async throws -> WikipediaSummary?)? = nil,
        recentContentCache: RecentContentCache = .shared,
        searchBehavior: SearchBehavior = .scoped
    ) {
        let service = musicBrainzService
        let localLibrary = LocalLibraryStore()
        let navidromeConnection = NavidromeConnectionStore()
        let rendererBrowser = UPnPRendererBrowser()
        let navidromeLibraryProvider = NavidromeLibraryProvider(
            connectionStore: navidromeConnection
        )
        let libraryManager = LibraryManager(
            localProvider: LocalLibraryProvider(store: localLibrary),
            navidromeProvider: navidromeLibraryProvider
        )
        let effectivePlaybackEngine: PlaybackEngine
        let rendererEngine: UPnPPlaybackEngine?
        if let playbackEngine {
            effectivePlaybackEngine = playbackEngine
            rendererEngine = nil
        } else {
            let upnpRendererEngine = UPnPPlaybackEngine(
                streamURLProvider: NavidromeRendererStreamURLProvider(
                    connection: navidromeConnection
                )
            )
            rendererEngine = upnpRendererEngine
            effectivePlaybackEngine = OutputRoutingPlaybackEngine(
                systemEngine: PlaybackEngineFactory.makeDefault(),
                rendererEngine: upnpRendererEngine,
                selection: {
                    guard libraryManager.source == .navidrome else {
                        return .system
                    }
                    if let renderer = rendererBrowser.selectedRenderer {
                        guard navidromeConnection.canUseRenderer else {
                            return .unavailable(name: renderer.friendlyName)
                        }
                        return .renderer(renderer)
                    }
                    if rendererBrowser.hasSelectedRendererPreference {
                        return .unavailable(
                            name: rendererBrowser.selectedRendererDisplayName
                                ?? "network renderer"
                        )
                    }
                    return .system
                },
                validatePlayback: {
                    guard libraryManager.source == .navidrome else { return }
                    try await navidromeConnection.requirePlaybackConnection()
                    if rendererBrowser.hasSelectedRendererPreference,
                       !navidromeConnection.canUseRenderer {
                        throw NavidromeConnectionStoreError.localConnectionRequired
                    }
                }
            )
        }
        let playbackController = PlaybackController(
            engine: effectivePlaybackEngine,
            assetResolver: libraryManager
        )
        rendererEngine?.nextItemProvider = { [weak playbackController] in
            try await playbackController?.resolvedNextItemForRenderer()
        }
        let releasePlaybackQueueBuilder = ReleasePlaybackQueueBuilder(
            libraryManager: libraryManager
        )

        self.navidromeConnection = navidromeConnection
        self.rendererBrowser = rendererBrowser
        self.localLibrary = localLibrary
        self.libraryManager = libraryManager
        self.releasePlaybackQueueBuilder = releasePlaybackQueueBuilder
        self.releaseDetailLoader = releaseDetailLoader ?? { id in
            try await service.loadRelease(id: id)
        }
        self.releaseCoverLoader = releaseCoverLoader ?? { id in
            await CoverArtCache.shared.image(for: id, size: .full)
        }
        self.artistDetailLoader = artistDetailLoader ?? { id in
            try await service.fetchArtist(id: id)
        }
        self.artistReleaseGroupsLoader = artistReleaseGroupsLoader
            ?? { id, limit, offset in
                try await service.fetchArtistReleaseGroups(
                    id: id,
                    limit: limit,
                    offset: offset
                )
            }
        self.artistWikipediaLoader = artistWikipediaLoader ?? { url in
            try await service.fetchWikipediaSummary(from: url)
        }
        self.recentContentCache = recentContentCache
        self.searchViewModel = SearchViewModel(
            service: service,
            libraryManager: libraryManager,
            searchBehavior: searchBehavior
        )
        self.trackDetailStore = TrackDetailStore(service: service)
        self.classicalMetadataStore = ClassicalMetadataStore(service: service)
        self.playbackController = playbackController
        self.rendererOutputObservation = rendererBrowser
            .$selectedRendererDisplayName
            .removeDuplicates()
            .sink { [weak playbackController] name in
                playbackController?.setExternalOutputDisplayName(name)
            }
        self.searchModeObservation = self.searchViewModel.objectWillChange
            .sink { [weak self] in
                // SearchViewModel publishes before its @Published value is
                // installed; yield once so the deck reads the new mode.
                Task { @MainActor [weak self] in
                    await Task.yield()
                    self?.objectWillChange.send()
                }
            }
        self.localPlaybackNowPlayingCoordinator =
            PlatformNowPlayingCoordinator(controller: self.playbackController)
        var previousEndpoint: URL?
        self.endpointObservation = navidromeConnection.$endpointState
            .removeDuplicates()
            .sink { [weak playbackController, weak navidromeConnection] state in
                guard state == .local || state == .remote || state == .unavailable else { return }
                Task { @MainActor [weak playbackController, weak navidromeConnection] in
                    await Task.yield()
                    guard let playbackController, let navidromeConnection,
                          navidromeConnection.endpointState == state else { return }
                    let endpoint = navidromeConnection.activeEndpointURL
                    if endpoint != previousEndpoint {
                        previousEndpoint = endpoint
                        playbackController.navidromeEndpointDidChange()
                    }
                    guard state != .local,
                          playbackController.externalOutputDisplayName != nil,
                          playbackController.status.isPlaying else { return }
                    await playbackController.pause()
                }
            }
        self.playbackItemObservation = self.playbackController.$currentIndex
            .map { $0 != nil }
            .removeDuplicates()
            .sink { [weak self] hasCurrentItem in
                self?.hasCurrentPlaybackItem = hasCurrentItem
            }

        rendererBrowser.selectionCommitHandler = { [weak self] in
            Task { @MainActor [weak self] in
                guard let self else { return }
                await self.playbackController.outputSelectionDidChange()
                await self.adoptRendererPlaybackIfAvailable(
                    provider: navidromeLibraryProvider
                )
            }
        }
        rendererBrowser.selectedRendererResolvedHandler = { [weak self] in
            Task { @MainActor [weak self] in
                guard let self else { return }
                await self.playbackController.refreshOutputVolume()
                await self.adoptRendererPlaybackIfAvailable(
                    provider: navidromeLibraryProvider
                )
            }
        }

        let restoredLibrarySource = LibrarySourcePreference.restoredSource(
            navidromeIsConfigured: navidromeConnection.isConfigured
        )
        self.activeLibrarySource = restoredLibrarySource
        libraryManager.setActiveSource(restoredLibrarySource)
        LibrarySourcePreference.save(restoredLibrarySource)
        if restoredLibrarySource != .navidrome {
            rendererBrowser.selectSystemAudioImmediately()
        }

        loadRecents()
        networkMonitor.pathUpdateHandler = { [weak self] _ in
            Task { @MainActor [weak self] in
                await self?.navidromeConnection.networkDidChange()
            }
        }
        if playbackEngine == nil {
            networkMonitor.start(queue: DispatchQueue(label: "MusiCards.network-path"))
        }
        if rendererBrowser.hasSelectedRendererPreference {
            rendererBrowser.refresh()
        }
        Task { [weak self] in
            await self?.refreshRecentReleaseMetadataFromCache()
        }
#if os(iOS)
        startNowPlayingUpdates()
        #endif
        #if os(macOS)
        localLibrary.startAutomaticRefresh()
        #endif
    }

    deinit {
        networkMonitor.cancel()
    }

    private func adoptRendererPlaybackIfAvailable(
        provider: NavidromeLibraryProvider
    ) async {
        guard activeLibrarySource == .navidrome else { return }
        guard playbackController.canAdoptRendererPlayback else { return }
        do {
            guard let snapshot = try await playbackController.rendererSnapshot(),
                  ["PLAYING", "PAUSED_PLAYBACK", "TRANSITIONING"].contains(
                    snapshot.transport.state.uppercased()
                  ),
                  let songID = UPnPPlaybackEngine.navidromeSongID(
                    in: snapshot.position.trackURI
                  ) else { return }
            let queue = try await provider.playbackQueue(
                containingNavidromeSongID: songID
            )
            guard playbackController.canAdoptRendererPlayback else { return }
            try await playbackController.adoptRendererPlayback(
                queue: queue,
                snapshot: snapshot
            )
            await preloadPlaybackContext(from: queue)
        } catch {
            // Discovery and ordinary local playback remain usable when an
            // external renderer session cannot be identified as Navidrome.
            Self.rendererAdoptionLogger.notice(
                "Renderer playback could not be adopted errorType=\(String(reflecting: type(of: error)), privacy: .public) detail=\(error.localizedDescription, privacy: .private)"
            )
        }
    }

    func preloadPlaybackContext(
        from queue: ReleasePlaybackQueue
    ) async {
        guard queue.items.indices.contains(queue.selectedIndex),
              let releaseID = queue.items[queue.selectedIndex].track.releaseID?
                .trimmingCharacters(in: .whitespacesAndNewlines),
              !releaseID.isEmpty,
              selectedReleaseID == nil || selectedReleaseID == releaseID else {
            return
        }

        if selectedRelease?.id != releaseID {
            releaseLoadTask?.cancel()
            releaseSelectionGeneration &+= 1
            let generation = releaseSelectionGeneration

            selectedReleaseID = releaseID
            isBackgroundReleaseLoad = true
            isLoadingRelease = true
            releaseError = nil
            selectedRelease = nil
            selectedReleaseCover = nil

            let task = Task(priority: .utility) { [weak self] in
                guard let self else { return }
                await self.loadReleaseAndCover(
                    id: releaseID,
                    generation: generation,
                    activateWhenLoaded: false
                )
            }
            releaseLoadTask = task
            await task.value

            guard generation == releaseSelectionGeneration,
                  selectedReleaseID == releaseID else { return }
            isBackgroundReleaseLoad = false
        }

        guard let release = selectedRelease,
              release.id == releaseID,
              selectedArtistID == nil,
              let artist = Self.unambiguousArtist(in: release) else { return }
        selectArtist(
            id: artist.id,
            name: artist.name,
            lifeSpan: nil,
            activateImmediately: false,
            priority: .utility
        )
    }

    func selectMusicFolder(_ url: URL) {
        localLibrary.selectMusicFolder(url)
    }

    func createOrUpdateLibraryIndex(_ url: URL) {
        #if os(macOS)
        localLibrary.createOrUpdateLibraryIndex(in: url)
        #endif
    }

    func disconnectMusicLibrary() {
        localLibrary.disconnectLibrary()
    }

    func restoreAudioOutputConfiguration() {
        playbackController.restoreOutputConfiguration()
    }

    func refreshActiveLibraryIfNeeded() {
        Task {
            if activeLibrarySource == .navidrome {
                await navidromeConnection.refreshReachableEndpoint()
                await libraryManager.refreshActiveCatalogIfNeeded()
            } else {
                await libraryManager.refreshActiveCatalogIfNeeded()
                await navidromeConnection.refreshReachableEndpoint()
            }
        }
    }

    func playIndexedTrack(
        releaseTrackID: String?,
        recordingID: String?
    ) {
        guard let release = selectedRelease else {
            return
        }
        let selection = ReleasePlaybackSelection(
            releaseTrackID: releaseTrackID,
            recordingID: recordingID
        )
        let playbackSource = libraryManager.source

        let request = playbackController.beginQueueRequest()
        Task {
            guard await playbackController.prepareForQueueReplacement(request)
            else { return }
            guard let queue = await releasePlaybackQueueBuilder.buildQueue(
                for: release,
                selection: selection,
                source: playbackSource,
                artworkData: playbackArtworkData()
            ) else {
                playbackController.abandonQueueRequest(request)
                return
            }
            guard await playbackController.replaceQueue(
                with: queue.items,
                startingAt: queue.selectedIndex,
                request: request
            ) else { return }
            await playbackController.play()
        }
    }

    private func playbackArtworkData() -> Data? {
        #if canImport(UIKit)
        selectedReleaseCover?.pngData()
        #elseif canImport(AppKit)
        selectedReleaseCover?.tiffRepresentation
        #else
        nil
        #endif
    }

    func playSelectedRelease() {
        guard let release = selectedRelease else { return }
        let playbackSource = libraryManager.source
        let request = playbackController.beginQueueRequest()
        Task {
            guard await playbackController.prepareForQueueReplacement(request)
            else { return }
            await libraryManager.prepareTrackAvailability(
                forRelease: release.id,
                from: playbackSource
            )
            guard let selection = releasePlaybackQueueBuilder
                .firstPlayableSelection(
                    in: release,
                    source: playbackSource
                ),
                  let queue = await releasePlaybackQueueBuilder.buildQueue(
                    for: release,
                    selection: selection,
                    source: playbackSource,
                    artworkData: playbackArtworkData()
                  ) else {
                playbackController.abandonQueueRequest(request)
                return
            }
            guard await playbackController.replaceQueue(
                with: queue.items,
                startingAt: queue.selectedIndex,
                request: request
            ) else { return }
            await playbackController.play()
        }
    }

    var isBlockingNavigationLoad: Bool {
        (isLoadingRelease && !isBackgroundReleaseLoad)
            || isLoadingArtistHeader
    }

    // MARK: - Release

    func selectRelease(
        _ row: SearchReleaseRow,
        activateImmediately: Bool = false
    ) {
        libraryArtistResolutionTask?.cancel()
        releaseLoadTask?.cancel()
        releaseSelectionGeneration &+= 1
        let generation = releaseSelectionGeneration

        isBackgroundReleaseLoad = false
        selectedReleaseID = row.id
        isLoadingRelease = true
        releaseError = nil
        selectedRelease = nil
        selectedReleaseCover = nil

        if activateImmediately {
            withAnimation(AppStyle.animation) {
                deckSelection = DeckSelection<MusiCardID>(
                    activeID: .release,
                    activeSlotIndex: MusiCardID.release.slotIndex
                )
            }
        }

        releaseLoadTask = Task {
            await loadReleaseAndCover(
                id: row.id,
                generation: generation,
                activateWhenLoaded: true
            )
        }
    }

    /// Recent-history mutation is deliberately a side effect of selecting
    /// the exact tapped Release, never a prerequisite for navigation.
    func selectRecentRelease(_ row: SearchReleaseRow) {
        selectRelease(row, activateImmediately: true)
        addRecentRelease(row)
    }

    func retryRelease() {
        guard let selectedReleaseID else { return }

        releaseLoadTask?.cancel()
        releaseSelectionGeneration &+= 1
        let generation = releaseSelectionGeneration

        isBackgroundReleaseLoad = false
        isLoadingRelease = true
        releaseError = nil
        selectedRelease = nil
        selectedReleaseCover = nil

        releaseLoadTask = Task {
            await loadReleaseAndCover(
                id: selectedReleaseID,
                generation: generation,
                activateWhenLoaded: true
            )
        }
    }

    private func loadReleaseAndCover(
        id: String,
        generation: UInt64,
        activateWhenLoaded: Bool
    ) async {
        if let cached = await recentContentCache.release(for: id) {
            guard generation == releaseSelectionGeneration,
                  selectedReleaseID == id else {
                return
            }
            selectedRelease = cached.release
            selectedReleaseCover = cached.coverData.flatMap(PlatformImage.init(data:))
            isLoadingRelease = false
            releaseError = nil
            updateRecentReleaseMetadata(from: cached.release)
            if activateWhenLoaded {
                activateReleaseCardIfNeeded()
            }
        }

        do {
            async let releaseTask = releaseDetailLoader(id)
            async let coverTask = releaseCoverLoader(id)

            let release = try await releaseTask
            let cover = await coverTask

            guard generation == releaseSelectionGeneration,
                  selectedReleaseID == id else {
                return
            }

            selectedRelease = release
            if let group = release.releaseGroup {
                libraryManager.rememberReleaseGroup(id: group.id, releaseIDs: [release.id])
            }
            selectedReleaseCover = cover
            isLoadingRelease = false
            releaseError = nil
            updateRecentReleaseMetadata(from: release)

            if activateWhenLoaded {
                activateReleaseCardIfNeeded()
            }

            if recentReleases.contains(where: { $0.id == id }) {
                await recentContentCache.save(
                    RecentReleaseSnapshot(
                        savedAt: Date(),
                        release: release,
                        coverData: imageData(for: cover)
                    ),
                    for: id
                )
            }
        } catch is CancellationError {
            return
        } catch {
            guard generation == releaseSelectionGeneration,
                  selectedReleaseID == id else {
                return
            }

            isLoadingRelease = false
            if selectedRelease?.id == id {
                releaseError = nil
            } else {
                selectedRelease = nil
                selectedReleaseCover = nil
                releaseError = error
            }
        }
    }

    private func activateReleaseCardIfNeeded() {
        guard deckSelection.activeID != .release else { return }
        withAnimation(AppStyle.animation) {
            deckSelection = DeckSelection<MusiCardID>(
                activeID: .release,
                activeSlotIndex: MusiCardID.release.slotIndex
            )
        }
    }

    private func imageData(for image: PlatformImage?) -> Data? {
        #if canImport(UIKit)
        image?.pngData()
        #elseif canImport(AppKit)
        image?.tiffRepresentation
        #else
        nil
        #endif
    }

    // MARK: - Artist

    func selectArtist(_ row: SearchArtistRow) {
        libraryArtistResolutionTask?.cancel()
        if row.id.hasPrefix("library-artist-") {
            let query = searchViewModel.searchQuery
            let generation = artistSelectionGeneration
            libraryArtistResolutionTask = Task { [weak self] in
                guard let self else { return }
                if let artist = await libraryManager.artistForLibraryCredit(row) {
                    guard !Task.isCancelled,
                          generation == artistSelectionGeneration,
                          query == searchViewModel.searchQuery else { return }
                    selectArtist(id: artist.id, name: artist.name, lifeSpan: nil)
                    return
                }
                guard !Task.isCancelled else { return }
                // Preserve exact-name resolution for older/single-artist rows
                // when release metadata is temporarily unavailable.
                do {
                    let matches = try await musicBrainzService.searchArtists(
                        query: row.name, limit: 5, offset: 0
                    )
                    guard !Task.isCancelled,
                          generation == artistSelectionGeneration,
                          query == searchViewModel.searchQuery,
                          let match = Self.exactArtistMatch(
                              named: row.name,
                              in: matches
                          ) else { return }
                    selectArtist(
                        id: match.id,
                        name: match.name,
                        lifeSpan: MBTextFormatter.lifeSpanTextOrEmpty(from: match.lifeSpan).nilIfEmpty
                    )
                } catch {
                    // The search card remains available; a later explicit
                    // MusicBrainz search can still resolve the artist.
                }
            }
            return
        }
        selectArtist(
            id: row.id,
            name: row.name,
            lifeSpan: row.lifeSpan.nilIfEmpty
        )
    }

    nonisolated static func exactArtistMatch(
        named artistName: String,
        in matches: [MBArtistSearchResult]
    ) -> MBArtistSearchResult? {
        let expectedName = normalizedArtistName(artistName)
        guard !expectedName.isEmpty else { return nil }
        return matches.first {
            normalizedArtistName($0.name) == expectedName
        }
    }

    nonisolated private static func normalizedArtistName(
        _ artistName: String
    ) -> String {
        artistName
            .split(whereSeparator: { $0.isWhitespace })
            .joined(separator: " ")
            .folding(
                options: [.caseInsensitive, .diacriticInsensitive],
                locale: Locale(identifier: "en_US_POSIX")
            )
    }

    func selectArtist(id: String) {
        selectArtist(id: id, name: nil, lifeSpan: nil)
    }

    private func selectArtist(
        id: String,
        name: String?,
        lifeSpan: String?,
        activateImmediately: Bool = true,
        priority: TaskPriority? = nil
    ) {
        libraryArtistResolutionTask?.cancel()
        artistLoadTask?.cancel()
        artistWikipediaTask?.cancel()
        artistDiscographyTask?.cancel()
        artistPaginationTask?.cancel()
        artistSelectionGeneration &+= 1
        let generation = artistSelectionGeneration

        // Reset pagination
        releaseGroupsOffset = 0
        hasMoreReleaseGroups = false
        isLoadingMoreReleaseGroups = false
        currentArtistIDForGroups = id

        selectedArtistID = id
        selectedArtist = nil
        selectedArtistName = name ?? ""
        selectedArtistLifeSpan = lifeSpan
        artistReleaseGroups = []
        discographyError = nil
        artistWikipedia = nil
        artistWikipediaError = nil
        isArtistWikipediaUnavailable = false
        artistError = nil

        isLoadingArtistHeader = false
        isLoadingArtistWikipedia = true
        isLoadingArtistDiscography = true

        if activateImmediately {
            withAnimation(AppStyle.animation) {
                deckSelection = DeckSelection<MusiCardID>(
                    activeID: .artist,
                    activeSlotIndex: MusiCardID.artist.slotIndex
                )
            }
        }
        artistLoadTask = Task(priority: priority) {
            await loadArtist(id: id, generation: generation)
        }
    }

    nonisolated static func unambiguousArtist(
        in release: MBRelease
    ) -> MBArtist? {
        guard let credits = release.artistCredit, !credits.isEmpty else {
            return nil
        }
        let artists = credits.compactMap(\.artist).filter {
            !$0.id.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        }
        guard artists.count == credits.count else { return nil }
        let artistsByID = Dictionary(
            artists.map { ($0.id.lowercased(), $0) },
            uniquingKeysWith: { first, _ in first }
        )
        guard artistsByID.count == 1,
              let artist = artistsByID.values.first,
              artist.id.lowercased()
                != "89ad4ac3-39f7-470e-963a-56509c546377" else {
            return nil
        }
        return artist
    }

    func retryArtist() {
        guard let artistID = selectedArtistID else { return }
        artistWikipediaTask?.cancel()
        artistError = nil
        artistWikipediaError = nil
        isArtistWikipediaUnavailable = false
        isLoadingArtistWikipedia = artistWikipedia == nil
        let generation = artistSelectionGeneration
        artistWikipediaTask = Task {
            await loadArtistDetail(id: artistID, generation: generation)
        }
    }

    func retryDiscography() {
        guard let artistID = selectedArtistID else { return }
        retryDiscography(for: artistID)
    }

    func retryArtistWikipedia() {
        guard let artistID = selectedArtistID else { return }
        artistWikipediaTask?.cancel()
        artistWikipediaError = nil
        isArtistWikipediaUnavailable = false
        isLoadingArtistWikipedia = artistWikipedia == nil
        let generation = artistSelectionGeneration
        artistWikipediaTask = Task {
            if let artist = selectedArtist {
                await loadArtistWikipedia(
                    for: artist,
                    id: artistID,
                    generation: generation
                )
            } else {
                await loadArtistDetail(id: artistID, generation: generation)
            }
        }
    }

    nonisolated static func hasUsableArtistHeader(
        artist: MBArtistDetail?,
        name: String
    ) -> Bool {
        artist != nil || !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    private func retryDiscography(for artistID: String) {
        artistDiscographyTask?.cancel()
        let generation = artistSelectionGeneration

        discographyError = nil
        artistReleaseGroups = []
        releaseGroupsOffset = 0
        hasMoreReleaseGroups = false
        isLoadingMoreReleaseGroups = false
        isLoadingArtistDiscography = true
        currentArtistIDForGroups = artistID

        artistDiscographyTask = Task {
            _ = await loadDiscographyPage(id: artistID, generation: generation)
        }
    }

    private func loadArtist(id: String, generation: UInt64) async {
        if let cached = await recentContentCache.artist(for: id) {
            guard generation == artistSelectionGeneration,
                  selectedArtistID == id else {
                return
            }
            selectedArtist = cached.artist
            selectedArtistName = cached.name
            selectedArtistLifeSpan = cached.lifeSpan
            artistReleaseGroups = cached.releaseGroups
            hasMoreReleaseGroups = cached.hasMoreReleaseGroups
            releaseGroupsOffset = cached.releaseGroups.count
            currentArtistIDForGroups = id
            if let title = cached.wikipediaTitle,
               let extract = cached.wikipediaExtract {
                let languageCode = cached.wikipediaLanguageCode ?? "en"
                if let pageURL = cached.wikipediaPageURL
                    ?? MusicBrainzService.wikipediaPageURL(
                        for: title,
                        languageCode: languageCode
                    ) {
                    artistWikipedia = WikipediaSummary(
                        title: title,
                        extract: extract,
                        languageCode: languageCode,
                        pageURL: pageURL
                    )
                }
            }
            discographyError = nil
            artistError = nil
        }

        guard generation == artistSelectionGeneration,
              selectedArtistID == id else { return }

        // Start the metadata/Wikipedia branch first. The discography branch is
        // independent and publishes as soon as its own first page arrives.
        artistWikipediaTask = Task {
            await loadArtistDetail(id: id, generation: generation)
        }
        await Task.yield()
        guard generation == artistSelectionGeneration,
              selectedArtistID == id else { return }
        artistDiscographyTask = Task {
            _ = await loadDiscographyPage(id: id, generation: generation)
        }
    }

    private func loadDiscographyPage(id: String, generation: UInt64) async -> Bool {
        if artistReleaseGroups.isEmpty {
            isLoadingArtistDiscography = true
        }
        defer {
            if generation == artistSelectionGeneration, selectedArtistID == id {
                isLoadingArtistDiscography = false
            }
        }
        do {
            let (groups, hasMore) = try await artistReleaseGroupsLoader(
                id,
                releaseGroupsPageSize,
                0
            )
            guard generation == artistSelectionGeneration, selectedArtistID == id else { return false }
            artistReleaseGroups = groups
            discographyError = nil
            hasMoreReleaseGroups = hasMore
            releaseGroupsOffset = groups.count
            currentArtistIDForGroups = id
            await cacheSelectedArtist(id: id, generation: generation)
            return true
        } catch is CancellationError { return false }
        catch {
            guard generation == artistSelectionGeneration, selectedArtistID == id else { return false }
            discographyError = error
            if !Self.hasUsableArtistHeader(artist: selectedArtist, name: selectedArtistName) {
                artistError = error
            }
            return false
        }
    }

    private func loadArtistDetail(id: String, generation: UInt64) async {
        do {
            let artist = try await artistDetailLoader(id)
            guard generation == artistSelectionGeneration, selectedArtistID == id else { return }
            selectedArtist = artist
            artistError = nil
            if selectedArtistName.isEmpty { selectedArtistName = artist.name }
            if selectedArtistLifeSpan == nil {
                selectedArtistLifeSpan = MBTextFormatter.lifeSpanText(from: artist.lifeSpan)
            }

            await loadArtistWikipedia(
                for: artist,
                id: id,
                generation: generation
            )

        } catch is CancellationError {
            return
        } catch {
            guard generation == artistSelectionGeneration, selectedArtistID == id else { return }
            isLoadingArtistWikipedia = false
            if artistWikipedia == nil {
                artistWikipediaError = error
            }
            if !Self.hasUsableArtistHeader(artist: selectedArtist, name: selectedArtistName) {
                artistError = error
            }
        }
    }

    private func loadArtistWikipedia(
        for artist: MBArtistDetail,
        id: String,
        generation: UInt64
    ) async {
        guard generation == artistSelectionGeneration,
              selectedArtistID == id else { return }

        // A cached excerpt stays visible while its network refresh runs.
        isLoadingArtistWikipedia = artistWikipedia == nil
        artistWikipediaError = nil
        isArtistWikipediaUnavailable = false

        guard let wikidataURL = artist.relations?
            .first(where: { $0.type == "wikidata" })?
            .url?
            .resource
            .flatMap(URL.init(string:)) else {
            if artistWikipedia == nil {
                isArtistWikipediaUnavailable = true
            }
            isLoadingArtistWikipedia = false
            await cacheSelectedArtist(id: id, generation: generation)
            return
        }

        do {
            let summary = try await artistWikipediaLoader(wikidataURL)
            guard generation == artistSelectionGeneration,
                  selectedArtistID == id else { return }
            artistWikipedia = summary
            isArtistWikipediaUnavailable = summary == nil
            isLoadingArtistWikipedia = false
            await cacheSelectedArtist(id: id, generation: generation)
        } catch is CancellationError {
            return
        } catch {
            guard generation == artistSelectionGeneration,
                  selectedArtistID == id else { return }
            isLoadingArtistWikipedia = false
            if artistWikipedia == nil {
                artistWikipediaError = error
            }
        }
    }

    private func cacheSelectedArtist(id: String, generation: UInt64) async {
        guard generation == artistSelectionGeneration,
              selectedArtistID == id,
              recentArtists.contains(where: { $0.id == id }) else {
            return
        }
        await recentContentCache.save(
            RecentArtistSnapshot(
                savedAt: Date(),
                artist: selectedArtist,
                name: selectedArtistName,
                lifeSpan: selectedArtistLifeSpan,
                releaseGroups: artistReleaseGroups,
                hasMoreReleaseGroups: hasMoreReleaseGroups,
                wikipediaTitle: artistWikipedia?.title,
                wikipediaExtract: artistWikipedia?.extract,
                wikipediaLanguageCode: artistWikipedia?.languageCode,
                wikipediaPageURL: artistWikipedia?.pageURL
            ),
            for: id
        )
    }

    // MARK: - Release group pagination

    func loadMoreReleaseGroupsIfNeeded(currentItem: MBReleaseGroupSummary) {
        guard !isLoadingMoreReleaseGroups, hasMoreReleaseGroups else { return }

        // Trigger when within 5 items of the end
        let threshold = max(artistReleaseGroups.count - 5, 0)
        guard let index = artistReleaseGroups.firstIndex(of: currentItem),
              index >= threshold else { return }

        isLoadingMoreReleaseGroups = true

        let generation = artistSelectionGeneration
        artistPaginationTask?.cancel()
        artistPaginationTask = Task { await loadMoreReleaseGroups(generation: generation) }
    }

    private func loadMoreReleaseGroups(generation: UInt64) async {
        defer {
            if generation == artistSelectionGeneration { isLoadingMoreReleaseGroups = false }
        }
        guard let artistID = currentArtistIDForGroups else {
            return
        }

        do {
            let (groups, hasMore) = try await artistReleaseGroupsLoader(
                artistID,
                releaseGroupsPageSize,
                releaseGroupsOffset
            )

            guard generation == artistSelectionGeneration, selectedArtistID == artistID else { return }

            artistReleaseGroups.append(contentsOf: groups)
            hasMoreReleaseGroups = hasMore
            releaseGroupsOffset += groups.count

        } catch {
            // Silently fail — user can scroll again to retry
        }

    }

    // MARK: - Release group selection

    func selectReleaseGroup(_ group: MBReleaseGroupSummary) {
        let artistName = selectedArtist?.name ?? selectedArtistName
        guard !artistName.isEmpty else { return }

        searchViewModel.loadReleaseGroupResults(
            releaseGroupID: group.id,
            releaseTitle: group.title,
            artistName: artistName
        )

        deckSelection = DeckSelection<MusiCardID>(
            activeID: .search,
            activeSlotIndex: MusiCardID.search.slotIndex
        )
    }

    // MARK: - Recents

    func addRecentArtist(_ artist: SearchArtistRow) {
        recentArtists.removeAll { $0.id == artist.id }
        recentArtists.insert(artist, at: 0)
        recentArtists = Array(recentArtists.prefix(3))
        saveRecents()
        pruneRecentContentCache()
    }

    func addRecentRelease(_ release: SearchReleaseRow) {
        recentReleases.removeAll { $0.id == release.id }
        recentReleases.insert(release, at: 0)
        recentReleases = Array(recentReleases.prefix(3))
        saveRecents()
        pruneRecentContentCache()
    }

    private func loadRecents() {
        let defaults = UserDefaults.standard

        if let artistData = defaults.data(forKey: recentArtistsKey),
           let decodedArtists = try? JSONDecoder().decode([SearchArtistRow].self, from: artistData) {
            recentArtists = decodedArtists
        }

        if let releaseData = defaults.data(forKey: recentReleasesKey),
           let decodedReleases = try? JSONDecoder().decode([SearchReleaseRow].self, from: releaseData) {
            recentReleases = decodedReleases
        }
    }

    private func saveRecents() {
        let defaults = UserDefaults.standard

        if let artistData = try? JSONEncoder().encode(recentArtists) {
            defaults.set(artistData, forKey: recentArtistsKey)
        }

        if let releaseData = try? JSONEncoder().encode(recentReleases) {
            defaults.set(releaseData, forKey: recentReleasesKey)
        }
    }

    private func refreshRecentReleaseMetadataFromCache() async {
        for id in recentReleases.map(\.id) {
            guard let cached = await recentContentCache.release(for: id) else {
                continue
            }
            updateRecentReleaseMetadata(from: cached.release)
        }
    }

    private func updateRecentReleaseMetadata(from release: MBRelease) {
        guard let index = recentReleases.firstIndex(where: {
            $0.id == release.id
        }) else {
            return
        }

        recentReleases[index] = recentReleases[index].enriched(with: release)
        saveRecents()
    }

    private func pruneRecentContentCache() {
        let artistIDs = Set(recentArtists.map(\.id))
        let releaseIDs = Set(recentReleases.map(\.id))
        Task {
            await recentContentCache.retain(
                artistIDs: artistIDs,
                releaseIDs: releaseIDs
            )
        }
    }

    // MARK: - Shazam

    func startShazamSearch() {
    #if os(iOS)
        guard !isShazamListening else { return }

        isShazamListening = true
        shazamStatusMessage = nil

        Task {
            do {
                let match = try await shazamService.recognize()

                Self.shazamLogger.debug(
                    "Shazam match artist=\(match.artist, privacy: .private) title=\(match.title, privacy: .private)"
                )

                searchViewModel.searchByRecognizedTrack(match)

                isShazamListening = false
                shazamStatusMessage = nil
                
            } catch {
                let nsError = error as NSError
                Self.shazamLogger.error(
                    "Shazam recognition failed domain=\(nsError.domain, privacy: .public) code=\(nsError.code, privacy: .public) detail=\(nsError.localizedDescription, privacy: .private)"
                )

                shazamStatusMessage = shazamMessage(for: error)

                Task {
                    try? await Task.sleep(nanoseconds: 1_500_000_000)
                    shazamStatusMessage = nil
                }

                isShazamListening = false
            }
        }
    #endif
    }
    
    private func shazamMessage(for error: Error) -> String {
    #if os(iOS)
        if let shazamError = error as? ShazamRecognitionError {
            switch shazamError {
            case .microphonePermissionDenied:
                return "Microphone access denied"
            case .noMatch:
                return "No match"
            case .missingTitleOrArtist:
                return "Incomplete Shazam match"
            }
        }
    #endif

        return "Shazam failed"
    }
    
    // MARK: - Now Playing

#if os(iOS)
    func openNowPlayingVersions() {
        guard
            let groupID = nowPlayingReleaseGroupID,
            let release = nowPlayingRelease
        else { return }

        searchViewModel.loadReleaseGroupResults(
            releaseGroupID: groupID,
            releaseTitle: nowPlayingReleaseGroupTitle ?? release.title,
            artistName: nowPlayingArtistName ?? release.artistLine
        )

        withAnimation(AppStyle.animation) {
            deckSelection = DeckSelection<MusiCardID>(
                activeID: .search,
                activeSlotIndex: MusiCardID.search.slotIndex
            )
        }
    }

    private func startNowPlayingUpdates() {
        guard nowPlayingObserver == nil else { return }

        let status = MPMediaLibrary.authorizationStatus()

        if status == .authorized {
            Task {
                await refreshNowPlayingRelease()
            }
        } else if status == .notDetermined {
            MPMediaLibrary.requestAuthorization { [weak self] newStatus in
                guard newStatus == .authorized else { return }

                Task { @MainActor in
                    await self?.refreshNowPlayingRelease()
                }
            }
        }

        let player = MPMusicPlayerController.systemMusicPlayer
        player.beginGeneratingPlaybackNotifications()

        nowPlayingObserver = NotificationCenter.default.addObserver(
            forName: .MPMusicPlayerControllerNowPlayingItemDidChange,
            object: player,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in
                await self?.refreshNowPlayingRelease()
            }
        }
    }

    private func refreshNowPlayingRelease() async {
        let item = MPMusicPlayerController.systemMusicPlayer.nowPlayingItem

        guard let album = item?.albumTitle,
              !album.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        else {
            nowPlayingRelease = nil
            nowPlayingReleaseGroupID = nil
            nowPlayingReleaseGroupTitle = nil
            nowPlayingArtistName = nil
            return
        }

        let artist =
            item?.albumArtist?.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty == false
            ? item?.albumArtist
            : item?.artist

        guard let artist,
              !artist.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        else {
            nowPlayingRelease = nil
            nowPlayingReleaseGroupID = nil
            nowPlayingReleaseGroupTitle = nil
            nowPlayingArtistName = nil
            return
        }

        do {
            let query = "\(artist), \(album)"

            let results = try await musicBrainzService.searchReleases(
                query: query,
                limit: 5,
                offset: 0
            )

            guard let best = results.first else {
                nowPlayingRelease = nil
                nowPlayingReleaseGroupID = nil
                nowPlayingReleaseGroupTitle = nil
                nowPlayingArtistName = nil
                return
            }

            let hasCoverArt = await CoverArtCache.shared.image(for: best.id, size: .thumbnail) != nil
            let detailedRelease = try? await musicBrainzService.loadRelease(id: best.id)

            nowPlayingRelease = SearchReleaseRow(
                id: best.id,
                title: best.title,
                artistLine: best.artistCredit?.compactMap { $0.name }.joined(separator: ", ") ?? "",
                metaLine: MBTextFormatter.releaseMetaLine(
                    year: MBTextFormatter.year(from: best.date),
                    country: best.country,
                    label: best.labelInfo?.compactMap { $0.label?.name }.first,
                    format: best.media?.compactMap { $0.format }.first
                ),
                disambiguation: best.disambiguation ?? "",
                hasCoverArt: hasCoverArt
            )

            nowPlayingReleaseGroupID = detailedRelease?.releaseGroup?.id
            nowPlayingReleaseGroupTitle = detailedRelease?.releaseGroup?.title ?? best.title
            nowPlayingArtistName = artist

        } catch {
            nowPlayingRelease = nil
            nowPlayingReleaseGroupID = nil
            nowPlayingReleaseGroupTitle = nil
            nowPlayingArtistName = nil
        }
    }
#endif
}

private extension String {
    var nilIfEmpty: String? {
        let value = trimmingCharacters(in: .whitespacesAndNewlines)
        return value.isEmpty ? nil : value
    }
}
