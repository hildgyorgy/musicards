//
//  ContentView.swift
//  MusiCards
//
//  Created by Hild György on 2026. 04. 05..
//

import SwiftUI
import UniformTypeIdentifiers

#if os(macOS)
import AppKit
#endif

struct ContentView: View {

    private var cards: [DeckCard<MusiCardID>] {

        let releaseTitle = appModel.selectedRelease?.title ?? "Release"

        let releaseSubtitle =
            appModel.selectedRelease?.artistCredit?
            .compactMap { $0.name }
            .joined(separator: ", ") ?? ""

        let artistTitle = appModel.selectedArtist?.name ?? "Artist"

        let artistSubtitle = MBTextFormatter.lifeSpanTextOrEmpty(
            from: appModel.selectedArtist?.lifeSpan
        )

        var result: [DeckCard<MusiCardID>] = []
        #if os(macOS)
            result.append(
                DeckCard(
                    id: .home,
                    slotIndex: MusiCardID.home.slotIndex,
                    cardLabel: "MusiCards",
                    title: "...",
                    subtitle: "..."
                )
            )
        #endif
        result.append(contentsOf: [
            DeckCard(
                id: .search,
                slotIndex: MusiCardID.search.slotIndex,
                cardLabel: appModel.searchViewModel.mode.cardLabel,
                title: "",
                subtitle: ""
            ),
            DeckCard(
                id: .release,
                slotIndex: MusiCardID.release.slotIndex,
                cardLabel: "Release",
                title: releaseTitle,
                subtitle: releaseSubtitle,
                scrollsHeaderInCompactLayout: true
            ),
            DeckCard(
                id: .tracks,
                slotIndex: MusiCardID.tracks.slotIndex,
                cardLabel: "Tracks",
                title: releaseTitle,
                subtitle: releaseSubtitle
            ),
            DeckCard(
                id: .artist,
                slotIndex: MusiCardID.artist.slotIndex,
                cardLabel: "Artist & Discography",
                title: artistTitle,
                subtitle: artistSubtitle
            ),
            DeckCard(
                id: .player,
                slotIndex: MusiCardID.player.slotIndex,
                cardLabel: "Player",
                title: "",
                subtitle: ""
            ),
        ])
        return result
    }

    @StateObject private var appModel = MusiCardsAppModel()
    @State private var isShowingAbout = false
    @State private var isShowingLibraryConnection = false
    @State private var isFolderImporterPresented = false
    @State private var openFolderImporterAfterSourceDismissal = false

    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.scenePhase) private var scenePhase

    var boxBackground: Color {
        colorScheme == .dark
            ? AppStyle.boxBackgroundDark
            : AppStyle.boxBackgroundLight
    }

    @ViewBuilder private func headerContent(_ card: DeckCard<MusiCardID>)
        -> some View
    {

        switch card.id {
        case .home:
            EmptyView()
        case .search:
            SearchCardHeaderView(
                viewModel: appModel.searchViewModel,
                isShazamListening: appModel.isShazamListening,
                onShazamTapped: {
                    appModel.startShazamSearch()
                },
                onTapCurrentArtist: {
                    withAnimation(AppStyle.animation) {
                        appModel.deckSelection.selectID(.artist, in: cards)
                    }
                },
                onBarcodeScanned: { code in
                    appModel.searchViewModel.searchByBarcode(code)
                },
                shazamStatusMessage: appModel.shazamStatusMessage
            )
        case .release:
            if appModel.isLoadingRelease {
                VStack(alignment: .leading, spacing: 12) {
                    MusiCardsSpinner()
                        .padding(.top, 8)
                }
            } else {
                ReleaseHeaderView(
                    release: appModel.selectedRelease,
                    coverImage: appModel.selectedReleaseCover,
                    isPlayable: appModel.selectedRelease.map {
                        appModel.libraryManager.containsRelease($0.id)
                    } ?? false,
                    onPlayRelease: {
                        appModel.playSelectedRelease()
                    },
                    onSelectArtist: { artistID in
                        selectArtistAfterViewUpdate(id: artistID)
                    }
                )
            }
        case .tracks:
            if let release = appModel.selectedRelease {
                TracksCardHeaderView(
                    title: release.title,
                    artistCredits: release.artistCredit,
                    onSelectArtist: { artistID in
                        selectArtistAfterViewUpdate(id: artistID)
                    }
                )
            } else {
                EmptyView()
            }
        case .artist:
            ArtistCardHeaderView(
                artist: appModel.selectedArtist,
                fallbackName: appModel.selectedArtistName,
                fallbackLifeSpan: appModel.selectedArtistLifeSpan
            )
        case .player:
            if appModel.deckSelection.activeID == .player {
                PlayerCardContentView(
                    controller: appModel.playbackController,
                    detailStore: appModel.trackDetailStore,
                    onSelectArtist: { artistID in
                        selectArtistAfterViewUpdate(id: artistID)
                    }
                )
            } else {
                EmptyView()
            }
        }
    }

    @ViewBuilder private func cardContent(_ card: DeckCard<MusiCardID>)
        -> some View
    {
        switch card.id {
        case .home:
                DeckBackgroundView(
                    localLibrary: appModel.localLibrary,
                    libraryManager: appModel.libraryManager,
                    navidromeConnection: appModel.navidromeConnection,
                    playbackController: appModel.playbackController,
                    rendererBrowser: appModel.rendererBrowser,
                    activeLibrarySource: $appModel.activeLibrarySource,
                onSelectMusicFolder: { url in
                    appModel.selectMusicFolder(url)
                },
                onCreateOrUpdateLibraryIndex: { url in
                    appModel.createOrUpdateLibraryIndex(url)
                },
                onDisconnectLibrary: {
                    appModel.disconnectMusicLibrary()
                },
                onShowAbout: {
                    isShowingAbout = true
                },
                onShowLibraryConnection: {
                    isShowingLibraryConnection = true
                }
            )
        case .search:
            SearchCardContentView(
                viewModel: appModel.searchViewModel,
                libraryManager: appModel.libraryManager,
                recentArtists: appModel.recentArtists,
                recentReleases: appModel.recentReleases,
                nowPlayingRelease: appModel.nowPlayingRelease,
                onSelectRelease: { row in
                    appModel.selectRelease(row)
                    appModel.addRecentRelease(row)
                },
                onSelectArtist: { artist in
                    selectArtistAfterViewUpdate(artist, addToRecents: true)
                },
                onSelectRecentArtist: { artist in
                    selectArtistAfterViewUpdate(artist, addToRecents: true)
                },
                onSelectRecentRelease: { release in
                    appModel.selectRecentRelease(release)
                },
                onSelectNowPlayingRelease: {
                    #if os(iOS)
                        appModel.openNowPlayingVersions()
                    #endif
                }
            )
        case .release:
            if appModel.isLoadingRelease {
                MusiCardsSpinner()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if let release = appModel.selectedRelease {
                ReleaseCardContentView(
                    release: release,
                    onShowVersions: {
                        guard let groupID = release.releaseGroup?.id else {
                            return
                        }
                        let artist =
                            release.artistCredit?
                            .compactMap { $0.name }
                            .joined(separator: ", ") ?? ""
                        appModel.searchViewModel.loadReleaseGroupResults(
                            releaseGroupID: groupID,
                            releaseTitle: release.title,
                            artistName: artist
                        )
                        withAnimation(AppStyle.animation) {
                            appModel.deckSelection.selectID(.search, in: cards)
                        }
                    }
                )
            } else if appModel.releaseError != nil {
                ErrorStateView.releaseRetry {
                    appModel.retryRelease()
                }
            } else {
                EmptyStateView.release
            }
        case .tracks:
            TracksCardContentView(
                release: appModel.selectedRelease,
                onSelectArtist: { artistID in
                    selectArtistAfterViewUpdate(id: artistID)
                },
                libraryManager: appModel.libraryManager,
                playbackController: appModel.playbackController,
                onPlayTrack: { releaseTrackID, recordingID in
                    appModel.playIndexedTrack(
                        releaseTrackID: releaseTrackID,
                        recordingID: recordingID
                    )
                },
                detailStore: appModel.trackDetailStore,
                classicalMetadataStore: appModel.classicalMetadataStore
            )
        case .artist:
            ArtistCardContentView(
                    libraryManager: appModel.libraryManager,
                    artist: appModel.selectedArtist,
                    artistName: appModel.selectedArtistName,
                    releaseGroups: appModel.artistReleaseGroups,
                    searchScope: appModel.searchViewModel.searchScope,
                    wikipedia: appModel.artistWikipedia,
                    discographyError: appModel.discographyError,
                    onSelectReleaseGroup: { group in
                        appModel.selectReleaseGroup(group)
                    },
                    onRetryDiscography: { appModel.retryDiscography() },
                    isLoadingWikipedia: appModel.isLoadingArtistWikipedia,
                    wikipediaError: appModel.artistWikipediaError,
                    isWikipediaUnavailable: appModel.isArtistWikipediaUnavailable,
                    onRetryWikipedia: { appModel.retryArtistWikipedia() },
                    isLoadingDiscography: appModel.isLoadingArtistDiscography,
                    artistError: appModel.artistError,
                    onRetryArtist: { appModel.retryArtist() },
                    isLoadingMore: appModel.isLoadingMoreReleaseGroups,
                    onLoadMoreIfNeeded: { group in
                        appModel.loadMoreReleaseGroupsIfNeeded(
                            currentItem: group
                        )
                    }
            )
        case .player:
            EmptyView()
        }
    }

    @ViewBuilder private func collapsedHeaderContent(
        _ card: DeckCard<MusiCardID>
    ) -> some View {
        if card.id == .player {
            CollapsedPlayerBar(controller: appModel.playbackController)
        } else {
            EmptyView()
        }
    }

    var body: some View {
        ZStack {
            #if os(macOS)
                DeckView(
                    cards: cards,
                    selection: $appModel.deckSelection,
                    showsCollapsedHeader: { card in
                        card.id == .player && appModel.hasCurrentPlaybackItem
                    },
                    collapsedHeaderProvider: { card in
                        collapsedHeaderContent(card)
                    },
                    headerProvider: { card in
                        headerContent(card)
                    },
                    contentProvider: { card in
                        cardContent(card)
                    }
                )
                .fileImporter(
                    isPresented: $isFolderImporterPresented,
                    allowedContentTypes: [.folder],
                    allowsMultipleSelection: false,
                    onCompletion: handleFolderImport
                )
                .sheet(
                    isPresented: $isShowingLibraryConnection,
                    onDismiss: handleSourceSheetDismissal
                ) {
                    LibraryConnectionView(
                        localLibrary: appModel.localLibrary,
                        navidromeConnection: appModel.navidromeConnection,
                        activeLibrarySource: $appModel.activeLibrarySource,
                        onConnectExisting: beginFolderImport,
                        onDisconnect: {
                            appModel.disconnectMusicLibrary()
                        }
                    )
                }
                .sheet(isPresented: $isShowingAbout) {
                    AboutSheetView()
                }

            #else
                GeometryReader { viewportProxy in
                    DeckView(
                        cards: cards,
                        viewportSafeAreaTop: viewportProxy.safeAreaInsets.top,
                        viewportSafeAreaBottom: viewportProxy.safeAreaInsets.bottom,
                        selection: $appModel.deckSelection,
                        showsCollapsedHeader: { card in
                            card.id == .player && appModel.hasCurrentPlaybackItem
                        },
                        collapsedHeaderProvider: { card in
                            collapsedHeaderContent(card)
                        },
                        headerProvider: { card in
                            headerContent(card)
                        },
                        contentProvider: { card in
                            cardContent(card)
                        },
                        background: {
                            ZStack {
                                boxBackground
                                DeckBackgroundView(
                                    localLibrary: appModel.localLibrary,
                                    libraryManager: appModel.libraryManager,
                                    navidromeConnection: appModel.navidromeConnection,
                                    playbackController: appModel.playbackController,
                                    rendererBrowser: appModel.rendererBrowser,
                                    activeLibrarySource: $appModel.activeLibrarySource,
                                    onSelectMusicFolder: { url in
                                        appModel.selectMusicFolder(url)
                                    },
                                    onCreateOrUpdateLibraryIndex: { url in
                                        appModel.createOrUpdateLibraryIndex(url)
                                    },
                                    onDisconnectLibrary: {
                                        appModel.disconnectMusicLibrary()
                                    }
                                )
                            }
                        }
                    )
                    .ignoresSafeArea()
                }
            #endif

            #if os(iOS)
                if appModel.isBlockingNavigationLoad {
                    ZStack {
                        MusiCardsSpinner()
                    }
                    .zIndex(999)
                    .transition(.opacity)
                }
            #endif
        }
        .animation(
            .easeInOut(duration: 0.15),
            value: appModel.isBlockingNavigationLoad
        )
        .onAppear {
            appModel.refreshActiveLibraryIfNeeded()
        }
        .onChange(of: scenePhase) { _, newPhase in
            if newPhase == .active {
                appModel.refreshActiveLibraryIfNeeded()
            }
        }
        #if os(macOS)
        .onReceive(
            NotificationCenter.default.publisher(
                for: NSApplication.willTerminateNotification
            )
        ) { _ in
            appModel.restoreAudioOutputConfiguration()
        }
        #endif
    }

    private func beginFolderImport() {
        openFolderImporterAfterSourceDismissal = true
        isShowingLibraryConnection = false
    }

    private func handleSourceSheetDismissal() {
        guard openFolderImporterAfterSourceDismissal else { return }
        openFolderImporterAfterSourceDismissal = false
        Task { @MainActor in
            await Task.yield()
            isFolderImporterPresented = true
        }
    }

    /// Artist links can be activated by SwiftUI while it is still completing
    /// the current view update (notably from the player's detail pager). Move
    /// the model mutation to the next MainActor turn so its published changes
    /// start a fresh update transaction.
    private func selectArtistAfterViewUpdate(id: String) {
        Task { @MainActor in
            await Task.yield()
            appModel.selectArtist(id: id)
        }
    }

    private func selectArtistAfterViewUpdate(
        _ artist: SearchArtistRow,
        addToRecents: Bool
    ) {
        Task { @MainActor in
            await Task.yield()
            appModel.selectArtist(artist)
            if addToRecents {
                appModel.addRecentArtist(artist)
            }
        }
    }

    private func handleFolderImport(
        _ result: Result<[URL], Error>
    ) {
        if case .success(let urls) = result,
           let url = urls.first {
            appModel.selectMusicFolder(url)
        }
        Task { @MainActor in
            await Task.yield()
            isShowingLibraryConnection = true
        }
    }
}
